# Machine Learning Examples

This repository contains several examples of assignments for the machine learning classes.
The assignment descriptions are in the notebooks.
